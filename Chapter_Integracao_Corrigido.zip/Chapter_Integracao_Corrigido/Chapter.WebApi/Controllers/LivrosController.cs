using Chapter.WebApi.Models;
using Chapter.WebApi.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Chapter.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class LivrosController : ControllerBase
    {
        private readonly LivroRepository _livroRepository;

        public LivrosController(LivroRepository livroRepository)
        {
            _livroRepository = livroRepository;
        }

        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(_livroRepository.Listar());
        }

        [HttpPost]
        public IActionResult Cadastrar(Livro livro)
        {
            if (livro == null || string.IsNullOrWhiteSpace(livro.Titulo) || livro.QuantidadePaginas <= 0)
            {
                return BadRequest("Dados do livro inválidos.");
            }

            _livroRepository.Cadastrar(livro);
            return CreatedAtAction(nameof(BuscarPorId), new { id = livro.Id }, livro);
        }

        [HttpGet("{id}")]
        public IActionResult BuscarPorId(int id)
        {
            Livro livro = _livroRepository.BuscarPorId(id);
            if (livro == null)
            {
                return NotFound();
            }

            return Ok(livro);
        }

        [AllowAnonymous]
        [HttpPut("{id}")]
        public IActionResult Atualizar(int id, Livro livro)
        {
            if (livro == null || string.IsNullOrWhiteSpace(livro.Titulo) || livro.QuantidadePaginas <= 0)
            {
                return BadRequest("Dados do livro inválidos.");
            }

            bool atualizado = _livroRepository.Atualizar(id, livro);
            if (!atualizado)
            {
                return NotFound();
            }

            return NoContent();
        }

        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Deletar(int id)
        {
            bool deletado = _livroRepository.Deletar(id);
            if (!deletado)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
