using Chapter.WebApi.Contexts;
using Chapter.WebApi.Models;
using System.Linq;

namespace Chapter.WebApi.Repositories
{
    public class UsuarioRepository
    {
        private readonly ChapterContext _context;

        public UsuarioRepository()
        {
        }

        public UsuarioRepository(ChapterContext context)
        {
            _context = context;
        }

        public virtual Usuario Login(string email, string senha)
        {
            return _context.Usuarios.FirstOrDefault(u => u.Email == email && u.Senha == senha);
        }
    }
}
