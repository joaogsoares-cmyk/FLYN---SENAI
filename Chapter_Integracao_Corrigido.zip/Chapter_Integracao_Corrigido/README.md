# Chapter WebApi - Testes de Integração e Correções (ASP.NET Core + EF Core)

Solução baseada no projeto `Chapter.zip` com as correções aplicadas na API Web e os testes automatizados de integração utilizando `TestServer` (`Microsoft.AspNetCore.TestHost`), `Microsoft.EntityFrameworkCore.InMemory` e **xUnit** (`Chapter.WebApi.Tests`), além dos testes unitários corrigidos em `Chapter.Tests`.

## Principais Falhas Identificadas e Corrigidas

1. **`ChapterContext.cs` / `Startup.cs`**: `OnConfiguring` sobrescrevia a injeção de dependência de `DbContextOptions` quando o contexto não estava configurado via `AddDbContext`. `Startup.cs` passou a registrar `AddDbContext<ChapterContext>` corretamente, permitindo substituir o provedor SQL Server pelo banco em memória (`InMemory`) durante os testes de integração.
2. **`LivrosController.cs`**:
   - `BuscarPorId(int id)` agora retorna `200 OK` com o livro ou `404 NotFound`.
   - `Atualizar(int id, Livro livro)` e `Deletar(int id)` agora verificam se o livro existe antes de atualizar/remover, retornando `404 NotFound` quando inexistente (evitando `ArgumentNullException` no `Update`/`Remove` do EF Core).
   - `Cadastrar(Livro livro)` valida título/páginas e retorna `201 Created` (`CreatedAtAction`) com o objeto criado e seu `Id`.
3. **`LivroRepository.cs`**:
   - Métodos marcados como `virtual` para compatibilidade com mocks (`Moq`) nos testes unitários.
   - Verificação de nulidade em `Atualizar` e `Deletar` antes de chamar `_context.Livros.Update` e `_context.Livros.Remove`.
4. **`Chapter.Tests/LivroControllerTest.cs`**:
   - Corrigida a asserção `Assert.AreEqual(200, okResult)` (que comparava `int` com `IActionResult`) para extrair `OkObjectResult` e validar `StatusCode == 200`.
5. **`Chapter.WebApi.Tests/LivrosControllerTests.cs`**:
   - Implementados os testes de integração HTTP (`GET`, `POST`, `PUT`, `DELETE`, `404 NotFound`, `400 BadRequest` e fluxo de autenticação JWT via `POST /api/login`) usando `TestServer` e banco em memória isolado.

## Como Executar

```bash
dotnet test --verbosity normal
```
