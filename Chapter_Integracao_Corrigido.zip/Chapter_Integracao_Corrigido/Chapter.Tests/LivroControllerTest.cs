using Chapter.WebApi.Controllers;
using Chapter.WebApi.Models;
using Chapter.WebApi.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;

namespace Chapter.Tests
{
    [TestClass]
    public class LivroControllerTest
    {
        private readonly List<Livro> _livros = new List<Livro>
        {
            new Livro { Id = 1, Titulo = "Sylvester", QuantidadePaginas = 8, Disponivel = true },
            new Livro { Id = 2, Titulo = "Whiskers", QuantidadePaginas = 2, Disponivel = true },
            new Livro { Id = 3, Titulo = "Sasha", QuantidadePaginas = 14, Disponivel = false }
        };

        [TestMethod]
        public void Get_QuandoChamado_RetornaResultadoDeOK()
        {
            var repository = new Mock<LivroRepository>();
            repository.Setup(x => x.Listar()).Returns(_livros);
            var controller = new LivrosController(repository.Object);

            var result = controller.Listar() as OkObjectResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(_livros, result.Value);
        }
    }
}
