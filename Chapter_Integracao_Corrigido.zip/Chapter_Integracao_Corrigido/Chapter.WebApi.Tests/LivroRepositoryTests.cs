using Chapter.WebApi.Contexts;
using Chapter.WebApi.Models;
using Chapter.WebApi.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using Xunit;

namespace Chapter.WebApi.Tests
{
    public class LivroRepositoryTests
    {
        private static ChapterContext CriarContextoInMemory()
        {
            var options = new DbContextOptionsBuilder<ChapterContext>()
                .UseInMemoryDatabase(databaseName: $"ChapterRepoTest_{Guid.NewGuid()}")
                .Options;

            return new ChapterContext(options);
        }

        [Fact]
        public void CadastrarEListar_DevePersistirNoEntityFrameworkInMemory()
        {
            using var context = CriarContextoInMemory();
            var repository = new LivroRepository(context);

            repository.Cadastrar(new Livro { Titulo = "Clean Code", QuantidadePaginas = 464, Disponivel = true });
            repository.Cadastrar(new Livro { Titulo = "Domain-Driven Design", QuantidadePaginas = 560, Disponivel = true });

            var lista = repository.Listar();

            Assert.Equal(2, lista.Count);
            Assert.Contains(lista, l => l.Titulo == "Clean Code");
        }

        [Fact]
        public void AtualizarEDeletar_DeveModificarERemoverRegistro()
        {
            using var context = CriarContextoInMemory();
            var repository = new LivroRepository(context);

            var livro = new Livro { Titulo = "Refactoring", QuantidadePaginas = 448, Disponivel = true };
            repository.Cadastrar(livro);

            bool atualizado = repository.Atualizar(livro.Id, new Livro
            {
                Titulo = "Refactoring 2nd Ed",
                QuantidadePaginas = 450,
                Disponivel = false
            });

            Assert.True(atualizado);
            var buscado = repository.BuscarPorId(livro.Id);
            Assert.Equal("Refactoring 2nd Ed", buscado.Titulo);
            Assert.False(buscado.Disponivel);

            bool deletado = repository.Deletar(livro.Id);
            Assert.True(deletado);
            Assert.Null(repository.BuscarPorId(livro.Id));
        }
    }
}
